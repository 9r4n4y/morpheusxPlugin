# Maximums Learning Memory

Keep this file small, durable, and useful. Store lessons, not a diary.

**Usage:** Maximums must read this file before non-trivial or multi-step work, apply relevant lessons, and update it when a durable improvement, correction, preference, or meaningful mistake is discovered.

## Workflow Rules
- Start normal web research with 1 targeted query and 1 SERP page.
- Use SERP snippets as leads; fetch only when snippets do not sufficiently answer the question.
- Fetch the strongest result first, then expand only when evidence is still missing.
- Prefer primary/official sources and stop when additional sources become repetitive.
- Use MorpheusX for research; use browser control mainly for interaction, screenshots, and visual/dynamic tasks.
- Avoid duplicate work across MorpheusX and browser tools.
- For large documents/files, target relevant sections instead of reading everything.

## User Preferences
- Optimize for token efficiency without sacrificing correctness.
- Answers should be structured and visually easy to scan.
- Put source links and supporting quotes in a separate section at the very end.

## Mistakes & Prevention
- Add meaningful failures as: `Mistake → Cause → Prevention`.

## Durable Lessons
- Add only lessons likely to improve future tasks.
- **Never use DeepSeek search** — no API key configured. Prefer web_search (Google/DuckDuckGo) or MorpheusX research tools; avoid DeepSeek web-search backend entirely.
