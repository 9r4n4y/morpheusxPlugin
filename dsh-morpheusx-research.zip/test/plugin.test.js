import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { __test, apply, name, inject } from '../index.js';

const root = dirname(dirname(fileURLToPath(import.meta.url)));

test('bundle metadata names the package and points to its Cordis patch', async () => {
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
  assert.equal(pkg.name, 'dsh-morpheusx-research');
  assert.equal(pkg.version, '2.1.0');
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml');
  assert.equal(name, pkg.name);
  assert.deepEqual(inject, ['tools']);
});

test('tool schema uses supported single type strings and exposes page controls', () => {
  const definitions = [];
  apply({ tools: { register(value) { definitions.push(value); } } });
  const definition = definitions.find(value => value.name === 'morpheusx_research');
  const tabsTool = definitions.find(value => value.name === 'morpheusx_search_tabs');
  const fetchTool = definitions.find(value => value.name === 'morpheusx_fetch_pages');
  assert.equal(definition.name, 'morpheusx_research');
  assert.ok(tabsTool);
  assert.ok(fetchTool);
  assert.equal(typeof definition.execute, 'function');
  assert.equal(definition.parameters.required[0], 'query');
  assert.equal(definition.parameters.properties.startPage.type, 'integer');
  assert.equal(definition.parameters.properties.pages.type, 'integer');
  assert.equal(definition.parameters.properties.allowRepeatPages.type, 'boolean');
  assert.equal(tabsTool.parameters.properties.action.type, 'string');
  assert.deepEqual(tabsTool.parameters.properties.action.enum, ['list', 'close']);
  assert.equal(definition.output.schema.properties.results.items.properties.snippet.type, 'string');
  assert.equal(definition.output.schema.properties.pageAudit.items.properties.status.type, 'string');
  const checkTypes = value => {
    if (!value || typeof value !== 'object') return;
    if (Object.hasOwn(value, 'type')) assert.equal(typeof value.type, 'string');
    for (const child of Object.values(value)) checkTypes(child);
  };
  checkTypes(definition.output.schema);
  checkTypes(tabsTool.output.schema);
  checkTypes(fetchTool.output.schema);
});

test('URL normalization removes tracking and fragments but keeps meaningful query order', () => {
  assert.equal(__test.normalizeUrl('https://Example.com/a/?first=1&utm_source=x&second=2#part'), 'https://example.com/a?first=1&second=2');
  assert.equal(__test.normalizeUrl('javascript:alert(1)'), null);
});

test('domain filters match exact hosts and subdomains only', () => {
  assert.equal(__test.isBlockedDomain('https://news.facebook.com/story', ['facebook.com']), true);
  assert.equal(__test.isBlockedDomain('https://notfacebook.com/story', ['facebook.com']), false);
  assert.equal(__test.isAllowedSource('https://example.com/story'), true);
  assert.equal(__test.isAllowedSource('http://127.0.0.1:8000/'), false);
  assert.equal(__test.isAllowedSource('http://printer.local/'), false);
});

test('fetch URL validation rejects private destinations including public-looking DNS names', async () => {
  await assert.rejects(__test.assertPublicUrl('http://127.0.0.1/admin'), /public HTTP\(S\)/);
  await assert.rejects(
    __test.assertPublicUrl('https://public-looking.example/page', new Map(), async () => [{ address: '10.0.0.8', family: 4 }]),
    /resolves to a private/,
  );
  const publicUrl = await __test.assertPublicUrl('https://public.example/page', new Map(), async () => [{ address: '93.184.216.34', family: 4 }]);
  assert.equal(publicUrl, 'https://public.example/page');
});

test('CDP endpoints are limited to localhost base URLs', () => {
  assert.throws(() => __test.normalizeEndpoint('http://192.168.1.2:9222'), /localhost/);
  assert.throws(() => __test.normalizeEndpoint('http://127.0.0.1:9222/devtools/browser/id'), /base URL/);
  assert.equal(__test.normalizeEndpoint('http://127.0.0.1:9222').origin, 'http://127.0.0.1:9222');
  assert.equal(__test.endpointHttpBase('ws://localhost:9222'), 'http://localhost:9222');
});

test('challenge detection recognizes search-engine challenges', () => {
  assert.equal(__test.challengeKind('Just a moment...', 'Checking your browser'), 'cloudflare_challenge');
  assert.equal(__test.challengeKind('Sign in to continue', 'Please log in'), 'login_required');
  assert.equal(__test.challengeKind('Google Search', 'Ten ordinary results'), '');
});

test('query and result file names are filesystem-safe', () => {
  assert.equal(__test.safeQueryName('CON: / research?'), 'CON_research');
  assert.equal(__test.safeQueryName('CON'), 'q_CON');
  assert.equal(__test.safeQueryName('...'), 'query');
  assert.equal(__test.safeSourceName('Café: first source!'), 'Cafe_first_source');
});

test('default request means one search-result page of ten results', async () => {
  const fileConfig = JSON.parse(await readFile(join(root, 'config.json'), 'utf8'));
  const config = __test.mergeConfig(fileConfig, { query: 'example' });
  assert.equal(config.startPage, 1);
  assert.equal(config.pages, 1);
  assert.equal(config.resultsPerPage, 10);
  assert.equal(config.maxResults, 10);
  assert.equal(config.maxSourceCharacters, 4000);
  assert.equal(config.allowRepeatPages, false);
  assert.equal(config.deduplicateResults, true);
    assert.equal(config.maxPageCharacters, 20000);
    assert.equal(config.maxLinksPerPage, 100);
    assert.equal(config.fetchConcurrency, 2);
});

test('four pages means pages one through four and up to forty results', () => {
  const config = __test.mergeConfig({}, { query: 'example', pages: 4 });
  assert.equal(config.startPage, 1);
  assert.equal(config.pages, 4);
  assert.equal(config.maxResults, 40);
});

test('a 30-result request derives three pages and a continuation starts after the prior pages', () => {
  const batch = __test.mergeConfig({}, { query: 'example', maxResults: 30 });
  assert.equal(batch.pages, 3);
  assert.equal(batch.maxResults, 30);
  const next = __test.mergeConfig({}, { query: 'example', startPage: 4, pages: 2 });
  assert.equal(next.startPage, 4);
  assert.equal(next.pages, 2);
  assert.equal(next.maxResults, 20);
});

test('search page URLs use SERP page offsets without opening a result URL', async () => {
  const config = { resultsPerPage: 10 };
  const google = new URL(__test.searchPageUrl('battery recycling', 4, config, 'google'));
  const ddg = new URL(__test.searchPageUrl('battery recycling', 4, config, 'duckduckgo'));
  assert.equal(google.hostname, 'www.google.com');
  assert.equal(google.searchParams.get('start'), '30');
  assert.equal(google.searchParams.get('num'), '10');
  assert.equal(ddg.searchParams.get('s'), '30');
  const code = await readFile(join(root, 'index.js'), 'utf8');
  assert.doesNotMatch(code, /page\.goto\(item\.url/);
  const searchPageCode = code.slice(code.indexOf('async function searchPage'), code.indexOf('function normalizeSearchResults'));
  assert.doesNotMatch(searchPageCode, /page\.close\(/);
});

test('search-result normalization extracts snippets, deduplicates, and enforces per-result cap', () => {
  const config = __test.mergeConfig({}, { query: 'example', maxSourceCharacters: 100 });
  const found = __test.normalizeSearchResults([
    { href: 'https://example.com/a', title: 'Example A', snippet: 'A'.repeat(150) },
    { href: 'https://example.com/a#duplicate', title: 'Duplicate', snippet: 'Another excerpt' },
    { href: 'https://www.google.com/search?q=internal', title: 'Google internal', snippet: 'Ignore' },
    { href: 'https://facebook.com/story', title: 'Blocked', snippet: 'Ignore' },
  ], 'google', 3, config);
  assert.equal(found.length, 1);
  assert.equal(found[0].title, 'Example A');
  assert.equal(found[0].searchPage, 3);
  assert.equal(found[0].snippet.length, 100);
});

test('character cap applies independently to each search result', () => {
  const cap = 1200;
  const results = [__test.limitSourceContent('A'.repeat(1500), cap), __test.limitSourceContent('B'.repeat(1500), cap)];
  assert.deepEqual(results.map(result => result.length), [cap, cap]);
  assert.equal(results.reduce((sum, result) => sum + result.length, 0), 2400);
});

test('each search result is saved separately with a continuation manifest', async () => {
  const base = await mkdtemp(join(tmpdir(), 'morpheusx-output-test-'));
  try {
    const config = __test.mergeConfig({}, { query: 'test query', outputDirectory: base, startPage: 4, pages: 2, sourceFormat: 'md' });
    const results = [
      { url: 'https://one.example/a', title: 'First', domain: 'one.example', snippet: 'First excerpt', searchPage: 4 },
      { url: 'https://two.example/b', title: 'Second', domain: 'two.example', snippet: 'Second excerpt', searchPage: 5 },
    ];
    const metadata = {
      query: 'test query', pagesSearched: 2, pagesVisited: [4, 5], skippedPages: [],
      pageAudit: [
        { page: 4, status: 'read', attempts: 1, extractedResults: 1, returnedResults: 1, tabIds: ['tab-4'] },
        { page: 5, status: 'read', attempts: 1, extractedResults: 1, returnedResults: 1, tabIds: ['tab-5'] },
      ],
      lastPageSearched: 5, searchErrors: [],
    };
    const first = await __test.writeOutputs(results, config, metadata);
    const second = await __test.writeOutputs(results, config, metadata);
    const files = await readdir(join(first.outDir, 'sources'));
    const manifest = JSON.parse(await readFile(first.manifestFile, 'utf8'));
    assert.equal(files.length, 2);
    assert.match(files[0], /^page-004-result-/);
    assert.match(files[1], /^page-005-result-/);
    assert.match(await readFile(join(first.outDir, 'sources', files[0]), 'utf8'), /First excerpt/);
    assert.equal(manifest.startPage, 4);
    assert.deepEqual(manifest.pagesVisited, [4, 5]);
    assert.deepEqual(manifest.skippedPages, []);
    assert.deepEqual(manifest.pageAudit, metadata.pageAudit);
    assert.equal(manifest.lastPageSearched, 5);
    assert.equal(manifest.results.length, 2);
    assert.equal('combinedReport' in manifest, false);
    assert.notEqual(first.outDir, second.outDir);
  } finally {
    await rm(base, { recursive: true, force: true });
  }
});

test('fetched pages are each saved with text, links, and per-page size metadata', async () => {
  const base = await mkdtemp(join(tmpdir(), 'morpheusx-fetch-test-'));
  try {
    const config = __test.mergeConfig({}, { outputDirectory: base, sourceFormat: 'md', maxPageCharacters: 1000 });
    const pages = [
      { inputIndex: 1, url: 'https://one.example/a', finalUrl: 'https://one.example/a', title: 'First page', domain: 'one.example', status: 'read', tabId: 'tab-a', httpStatus: 200, extractedCharacters: 12, returnedCharacters: 12, truncated: false, content: 'Readable text', contentFile: '', links: [{ text: 'Next', url: 'https://one.example/next' }] },
      { inputIndex: 2, url: 'http://127.0.0.1/private', finalUrl: '', title: '', domain: '', status: 'rejected', tabId: '', extractedCharacters: 0, returnedCharacters: 0, truncated: false, content: '', contentFile: '', links: [], error: 'private' },
      { inputIndex: 3, url: 'https://three.example/empty', finalUrl: 'https://three.example/empty', title: 'Empty page', domain: 'three.example', status: 'empty', tabId: 'tab-c', httpStatus: 200, extractedCharacters: 0, returnedCharacters: 0, truncated: false, content: '', contentFile: '', links: [], error: 'empty' },
    ];
    const output = await __test.writeFetchedPages(pages, config, 3);
    assert.equal(output.pagesAttempted, 2);
    assert.equal(output.pagesRead, 1);
    assert.match(output.pages[0].contentFile, /source-001-one.example-First_page\.md$/);
    assert.match(await readFile(output.pages[0].contentFile, 'utf8'), /Readable text/);
    const manifest = JSON.parse(await readFile(output.manifestFile, 'utf8'));
    assert.equal(manifest.pagesRead, 1);
    assert.equal(manifest.pages[0].links.length, 1);
    assert.equal(manifest.pages[2].status, 'empty');
    assert.equal('content' in manifest.pages[0], false);
  } finally {
    await rm(base, { recursive: true, force: true });
  }
});

test('selected URLs each get an independent retained tab and empty pages are not counted as reads', async () => {
  const opened = [];
  const context = {
    async newPage() {
      let title = '';
      let currentUrl = '';
      const page = {
        async evaluate(_fn, argument) {
          if (typeof argument === 'string') title = argument;
          else return { title: 'Fetched article', text: currentUrl.includes('/empty') ? '' : 'Article text', links: [] };
        },
        async route() {},
        async goto(url) { currentUrl = url; title = url.includes('/empty') ? 'Empty page' : 'Fetched article'; return { status: () => 200 }; },
        async waitForTimeout() {},
        async title() { return title; },
        async locator() { return { innerText: async () => '' }; },
        url() { return currentUrl; },
      };
      opened.push(page);
      return page;
    },
  };
  const config = { maxLinksPerPage: 100, maxPageCharacters: 20000, mediaBlocking: true, pageLoadTimeoutMs: 35000, searchSettleMs: 0 };
  const urls = ['https://93.184.216.34/article', 'https://93.184.216.35/empty'];
  const pages = await Promise.all(urls.map((url, index) => __test.fetchOnePage(context, url, index + 1, config, new Map())));
  assert.equal(opened.length, 2);
  assert.notEqual(pages[0].tabId, pages[1].tabId);
  assert.equal(pages[0].status, 'read');
  assert.equal(pages[0].content, 'Article text');
  assert.equal(pages[1].status, 'empty');
  assert.equal(pages[1].tabId.length > 0, true);
});

test('search history remembers SERP pages by normalized query and URLs across queries', async () => {
  const base = await mkdtemp(join(tmpdir(), 'morpheusx-history-test-'));
  try {
    const config = __test.mergeConfig({}, { query: 'battery recycling', outputDirectory: base });
    const results = [{ url: 'https://example.com/a?utm_source=google', title: 'Example', domain: 'example.com', snippet: 'Excerpt', searchPage: 2 }];
    await __test.writeOutputs(results, config, {
      query: 'Battery   Recycling', pagesSearched: 1, pagesVisited: [2], skippedPages: [], lastPageSearched: 2, searchErrors: [],
    });
    await __test.writeOutputs([], __test.mergeConfig({}, { query: 'battery recycling', outputDirectory: base, startPage: 6 }), {
      query: 'Battery Recycling', startPage: 6, pagesSearched: 1, pagesVisited: [], skippedPages: [], lastPageSearched: 2, searchErrors: ['page load failed'],
    });
    const history = await __test.loadSearchHistory(config);
    assert.deepEqual([...history.searchedPages.get('battery recycling')], [2]);
    assert.equal(history.seenUrls.has('https://example.com/a'), true);
  } finally {
    await rm(base, { recursive: true, force: true });
  }
});

test('search tab manager lists and closes only selected MorpheusX SERP tabs', async () => {
  const closed = [];
  const context = { pages: () => [
    { title: async () => 'MorpheusX SERP | abc-123 | p2 | query', url: () => 'https://www.google.com/search?q=query&start=10', close: async () => closed.push('abc-123') },
    { title: async () => 'MorpheusX Source | src-2 | Example article', url: () => 'https://example.com/article', close: async () => closed.push('src-2') },
    { title: async () => 'MorpheusX SERP | fail-9 | p1 | query', url: () => 'https://www.google.com/search?q=query', close: async () => { throw new Error('browser refused'); } },
    { title: async () => 'Google Search', url: () => 'https://www.google.com/search?q=personal', close: async () => closed.push('user') },
  ] };
  const tabs = await __test.listSearchTabs(context);
  assert.equal(tabs.length, 3);
  const firstTab = tabs.find(tab => tab.id === 'abc-123');
  assert.equal(firstTab.kind, 'serp');
  assert.equal(firstTab.page, 2);
  assert.equal(firstTab.query, 'query');
  const sourceTab = tabs.find(tab => tab.id === 'src-2');
  assert.equal(sourceTab.kind, 'source');
  assert.equal(sourceTab.searchEngine, 'webpage');
  const result = await __test.closeSearchTabs(context, ['abc-123', 'src-2', 'fail-9', 'not-open']);
  assert.deepEqual(closed, ['abc-123', 'src-2']);
  assert.deepEqual(result.closedTabIds, ['abc-123', 'src-2']);
  assert.deepEqual(result.notFoundTabIds, ['not-open']);
  assert.deepEqual(result.failedTabIds, ['fail-9']);
});

test('configuration bounds page, result, wait, retry, and per-result controls', () => {
  const config = __test.mergeConfig({}, { query: 'x', pages: 120, startPage: 0, resultsPerPage: 500, maxResults: 3000, retryCount: 8, searchSettleMs: -20, maxSourceCharacters: 10 });
  assert.equal(config.pages, 100);
  assert.equal(config.startPage, 1);
  assert.equal(config.resultsPerPage, 100);
  assert.equal(config.maxResults, 1000);
  assert.equal(config.retryCount, 3);
  assert.equal(config.searchSettleMs, 0);
  assert.equal(config.maxSourceCharacters, 100);
});
