# DeepSeek Harness GUI Plugin Research

Research was performed on 2026-10-07. Google was queried first for the exact topic, `DeepSeek Harness plugin system GUI`. Primary official DeepSeek Harness documentation and the `deepseek-ai/deepseek-harness` repository were then opened in separate tabs in the user's already-running localhost CDP browser session. The content listed as fully readable below was read from page bodies, not search snippets.

## Findings

- A Harness installable plugin is distributed as a bundle: `package.json` declares `dsh.bundle.patch`, and the patch inserts the Cordis plugin module as a loader row. This is distinct from the profile manifest, which selects bundle layers.
- The module exports `name`, declares dependencies such as `inject = ['tools']`, and implements `apply(ctx)`. Cordis waits for injected services and releases effect-managed registrations when a plugin unloads.
- The supported model-facing tool registry is `ctx.tools.register()`. The official authoring path uses `defineTool` from `@deepseek-ai/dsh-tools`; the official cookbook also confirms raw JSON-Schema tool definitions are accepted. This package uses that native schema form so it does not import a Harness internal helper at runtime.
- In the GUI, the Plugins page can install a third-party plugin from a package name, Git repository, or local directory. A ZIP must be extracted before choosing the folder. Bundle activation and row enablement are managed by the page/profile.
- Profile bundle layers are composed in order, followed by profile and home patch layers. Plugin Manager writes row enablement to the profile patch; HMR can recompose the running tree. Package peer-version checks may reject a package before installation.
- CDP is external to Harness. This plugin connects only to loopback CDP, keeps the existing browser running, and does not launch a browser or close pre-existing tabs.

## Fully readable pages

All 20 unique sources below were fully readable. Each was opened in its own browser tab before page content was reviewed.

1. [DeepSeek Harness repository](https://github.com/deepseek-ai/deepseek-harness)
2. [Harness architecture](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/architecture.md)
3. [Package and install a plugin](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md)
4. [Your first plugin](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/index.md)
5. [Tool registry README](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/core/tools/README.md)
6. [Tools subsystem reference](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/subsystems/tools.md)
7. [GUI Plugin Manager](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/client/ui-plugin-manager/README.md)
8. [Plugin Manager service](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/boot/plugin-manager/README.md)
9. [CLI plugin/profile reference](https://github.com/deepseek-ai/deepseek-harness/blob/master/apps/cli/reference/README.md)
10. [Cordis Context API](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-api/context.md)
11. [Composition and hot module replacement](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-tutorial/06-composition-and-hmr.md)
12. [Extension cookbook](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cookbook/extension-cookbook.md)
13. [Tool schema catalog](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/tool-catalog.md)
14. [Application boot and profiles](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/boot/app-boot/README.md)
15. [CLI application README](https://github.com/deepseek-ai/deepseek-harness/blob/master/apps/cli/README.md)
16. [Cordis tutorial overview](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-tutorial/index.md)
17. [Cordis inspection tool README](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/extensions/tool-cordis/README.md)
18. [Harness core package map](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/core/README.md)
19. [Build a tool tutorial](https://deepseek-harness.github.io/deepseek-harness/en/develop/basic/tool)
20. [Services and dependencies](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/framework/service.md)

## Partially readable pages

- [DeepSeek Harness marketing page](https://deepseek.com/harness/en/) returned a moved-page response with no substantive page body. It was not used for implementation claims.

## Blocked or unavailable pages

- An attempted third-party mirror of the Cordis first-plugin tutorial returned GitHub's `File not found` page. It was not counted among the 20 sources and was replaced with the official `Build a tool` tutorial above.
- No CAPTCHA, Cloudflare, login, or anti-bot challenge appeared on the pages used.
