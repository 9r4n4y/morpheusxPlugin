import { execFile } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { lookup } from 'node:dns/promises';
import { promisify } from 'node:util';
import { mkdir, mkdtemp, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isIP } from 'node:net';
import { chromium } from 'playwright-core';

const execFileAsync = promisify(execFile);
const ROOT = dirname(fileURLToPath(import.meta.url));
const MEDIA_TYPES = new Set(['image', 'media', 'font', 'manifest', 'texttrack']);
const MAX_PORT = 65535;
const DEFAULT_PORTS = Array.from({ length: 9 }, (_, index) => 9222 + index);
const TRACKING_KEYS = /^(utm_.+|fbclid|gclid|dclid|msclkid|mc_cid|mc_eid|igshid|ref_src|ref_url)$/i;
const DEFAULT_CONFIG = Object.freeze({
  cdpEndpoint: 'http://127.0.0.1:9222',
  candidatePorts: DEFAULT_PORTS,
  searchEngine: 'google',
  startPage: 1,
  pages: 1,
  resultsPerPage: 10,
  maxSourceCharacters: 4000,
  pageLoadTimeoutMs: 35000,
  searchSettleMs: 450,
  blockedDomains: ['instagram.com', 'facebook.com'],
  outputDirectory: './outputs',
  sourceFormat: 'md',
  retryCount: 1,
  mediaBlocking: true,
  allowRepeatPages: false,
  deduplicateResults: true,
  maxPageCharacters: 20000,
  maxLinksPerPage: 100,
  fetchConcurrency: 2,
});
let activeBrowser;
let activeEndpoint;
const SEARCH_TAB_PREFIX = 'MorpheusX SERP |';
const SOURCE_TAB_PREFIX = 'MorpheusX Source |';

export const name = 'dsh-morpheusx-research';
export const inject = ['tools'];

const parameterFields = {
  query: { type: 'string', description: 'Research query.' },
  searchEngine: { type: 'string', enum: ['google', 'duckduckgo'], description: 'Search provider. Default: Google.' },
  startPage: { type: 'integer', minimum: 1, maximum: 10000, description: 'First search-result page to inspect. Continue at the last inspected page plus one to avoid repeats.' },
  pages: { type: 'integer', minimum: 1, maximum: 100, description: 'Number of consecutive search-result pages, starting at startPage. Default: 1 page.' },
  maxResults: { type: 'integer', minimum: 1, maximum: 1000, description: 'Optional total result count. If pages is omitted, pages are calculated from maxResults/resultsPerPage. Default: 10 results.' },
  resultsPerPage: { type: 'integer', minimum: 1, maximum: 100, description: 'Results requested per search page. Default: 10.' },
  cdpEndpoint: { type: 'string', description: 'Optional localhost CDP base URL, such as http://127.0.0.1:9222.' },
  candidatePorts: { type: 'array', items: { type: 'integer', minimum: 1, maximum: MAX_PORT }, description: 'Local CDP ports to probe after the configured endpoint.' },
  maxSourceCharacters: { type: 'integer', minimum: 100, maximum: 1000000, description: 'Maximum snippet characters retained for each individual search result. Full result pages are fetched only through morpheusx_fetch_pages.' },
  pageLoadTimeoutMs: { type: 'integer', minimum: 1000, maximum: 120000, description: 'Per-search-page navigation timeout in milliseconds.' },
  searchSettleMs: { type: 'integer', minimum: 0, maximum: 10000, description: 'Wait after a search page loads before reading results.' },
  retryCount: { type: 'integer', minimum: 0, maximum: 3, description: 'Retries for a failed search-results page.' },
  blockedDomains: { type: 'array', items: { type: 'string' }, description: 'Exact domains to block, including their subdomains.' },
  outputDirectory: { type: 'string', description: 'Absolute output directory or a path relative to this plugin package.' },
  sourceFormat: { type: 'string', enum: ['md', 'txt'], description: 'Format of each individual source file.' },
  allowRepeatPages: { type: 'boolean', description: 'Allow searching a query/page already recorded in output history. Default: false.' },
  deduplicateResults: { type: 'boolean', description: 'Skip result URLs already returned by earlier runs under this output directory. Default: true.' },
};

const fetchParameters = {
  urls: { type: 'array', items: { type: 'string' }, description: 'One or more explicitly selected public HTTP(S) page URLs. Each valid URL opens in its own retained browser tab. Maximum 20 URLs per call.' },
  maxPageCharacters: { type: 'integer', minimum: 1000, maximum: 500000, description: 'Maximum readable text characters returned and saved per fetched page. There is no combined cap.' },
  maxLinksPerPage: { type: 'integer', minimum: 0, maximum: 1000, description: 'Maximum public HTTP(S) hyperlinks to return from each fetched page.' },
  fetchConcurrency: { type: 'integer', minimum: 1, maximum: 5, description: 'Maximum page navigations in parallel; default 2.' },
  pageLoadTimeoutMs: parameterFields.pageLoadTimeoutMs,
  searchSettleMs: parameterFields.searchSettleMs,
  cdpEndpoint: parameterFields.cdpEndpoint,
  candidatePorts: parameterFields.candidatePorts,
  outputDirectory: parameterFields.outputDirectory,
  sourceFormat: parameterFields.sourceFormat,
  mediaBlocking: { type: 'boolean', description: 'Block images, video, audio, and fonts while extracting text. Default: true.' },
};

const outputSchema = {
  type: 'object',
  properties: {
    query: { type: 'string' },
    cdpEndpoint: { type: 'string' },
    searchEngine: { type: 'string' },
    startPage: { type: 'integer' },
    pagesRequested: { type: 'integer' },
    pagesSearched: { type: 'integer' },
    pagesVisited: { type: 'array', items: { type: 'integer' } },
    skippedPages: { type: 'array', items: { type: 'integer' } },
    pageAudit: { type: 'array', items: { type: 'object', properties: {
      page: { type: 'integer' }, status: { type: 'string' }, attempts: { type: 'integer' }, httpStatus: { type: 'integer' }, extractedResults: { type: 'integer' }, returnedResults: { type: 'integer' }, tabIds: { type: 'array', items: { type: 'string' } }, error: { type: 'string' },
    }, required: ['page', 'status', 'attempts', 'extractedResults', 'returnedResults', 'tabIds'] } },
    lastPageSearched: { type: 'integer' },
    resultsPerPage: { type: 'integer' },
    maxResults: { type: 'integer' },
    resultCount: { type: 'integer' },
    outputDirectory: { type: 'string' },
    manifestFile: { type: 'string' },
    results: { type: 'array', items: {
      type: 'object',
      properties: {
        url: { type: 'string' }, title: { type: 'string' }, domain: { type: 'string' }, snippet: { type: 'string' }, contentFile: { type: 'string' }, searchPage: { type: 'integer' },
      },
      required: ['url', 'title', 'domain', 'snippet', 'contentFile', 'searchPage'],
    } },
    searchErrors: { type: 'array', items: { type: 'string' } },
  },
  required: ['query', 'cdpEndpoint', 'searchEngine', 'startPage', 'pagesRequested', 'pagesSearched', 'pagesVisited', 'skippedPages', 'pageAudit', 'lastPageSearched', 'resultsPerPage', 'maxResults', 'resultCount', 'outputDirectory', 'manifestFile', 'results', 'searchErrors'],
};

const fetchOutputSchema = {
  type: 'object',
  properties: {
    urlsRequested: { type: 'integer' },
    pagesAttempted: { type: 'integer' },
    pagesRead: { type: 'integer' },
    pages: { type: 'array', items: { type: 'object', properties: {
      inputIndex: { type: 'integer' }, url: { type: 'string' }, finalUrl: { type: 'string' }, title: { type: 'string' }, domain: { type: 'string' },
      status: { type: 'string', description: 'read, empty, challenge, failed, rejected, or duplicate. Only read counts toward pagesRead.' }, tabId: { type: 'string' }, httpStatus: { type: 'integer' }, extractedCharacters: { type: 'integer' },
      returnedCharacters: { type: 'integer' }, truncated: { type: 'boolean' }, content: { type: 'string' }, contentFile: { type: 'string' },
      duplicateOfInputIndex: { type: 'integer' },
      links: { type: 'array', items: { type: 'object', properties: { text: { type: 'string' }, url: { type: 'string' } }, required: ['text', 'url'] } },
      error: { type: 'string' },
    }, required: ['inputIndex', 'url', 'finalUrl', 'title', 'domain', 'status', 'tabId', 'extractedCharacters', 'returnedCharacters', 'truncated', 'content', 'contentFile', 'links'] } },
    manifestFile: { type: 'string' },
    outputDirectory: { type: 'string' },
    errors: { type: 'array', items: { type: 'string' } },
  },
  required: ['urlsRequested', 'pagesAttempted', 'pagesRead', 'pages', 'manifestFile', 'outputDirectory', 'errors'],
};

function boundedInteger(value, fallback, min, max) {
  const parsed = Number.isInteger(value) ? value : fallback;
  return Math.min(max, Math.max(min, parsed));
}

function normalizeEndpoint(value) {
  let url;
  try { url = new URL(value); } catch { throw new Error('cdpEndpoint must be a localhost URL.'); }
  if (!['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol)) throw new Error('cdpEndpoint must use HTTP(S) or WS(S).');
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (!['127.0.0.1', 'localhost', '::1'].includes(host)) throw new Error('CDP connections are limited to localhost (127.0.0.1, localhost, or ::1).');
  if (!url.port || Number(url.port) < 1 || Number(url.port) > MAX_PORT) throw new Error('cdpEndpoint must include a valid port.');
  if (url.pathname.startsWith('/devtools/')) throw new Error('Pass the CDP base URL, not a browser WebSocket URL.');
  return url;
}

function endpointAt(host, port, protocol = 'http:') {
  return `${protocol}//${host.includes(':') ? `[${host}]` : host}:${port}`;
}

function endpointHttpBase(value) {
  const url = normalizeEndpoint(value);
  const protocol = url.protocol === 'ws:' ? 'http:' : url.protocol === 'wss:' ? 'https:' : url.protocol;
  return endpointAt(url.hostname.replace(/^\[|\]$/g, ''), Number(url.port), protocol);
}

function normalizeUrl(raw) {
  let candidate;
  try { candidate = new URL(String(raw).trim()); } catch { return null; }
  if (!['http:', 'https:'].includes(candidate.protocol) || !candidate.hostname || candidate.username || candidate.password) return null;
  candidate.hash = '';
  for (const key of [...candidate.searchParams.keys()]) if (TRACKING_KEYS.test(key)) candidate.searchParams.delete(key);
  if (candidate.pathname.length > 1) candidate.pathname = candidate.pathname.replace(/\/+$/, '');
  return candidate.toString();
}

function isPrivateAddress(host) {
  const ipType = isIP(host);
  if (ipType === 4) {
    const octets = host.split('.').map(Number);
    return octets[0] === 0 || octets[0] === 10 || octets[0] === 127 ||
      (octets[0] === 169 && octets[1] === 254) || (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31) ||
      (octets[0] === 192 && (octets[1] === 168 || (octets[1] === 0 && octets[2] <= 2))) ||
      (octets[0] === 100 && octets[1] >= 64 && octets[1] <= 127) ||
      (octets[0] === 198 && (octets[1] === 18 || octets[1] === 19 || (octets[1] === 51 && octets[2] === 100))) ||
      (octets[0] === 203 && octets[1] === 0 && octets[2] === 113) || octets[0] >= 224;
  }
  if (ipType === 6) {
    const normalized = host.toLowerCase();
    return normalized === '::' || normalized === '::1' || normalized.startsWith('fc') || normalized.startsWith('fd') ||
      normalized.startsWith('fe80:') || normalized.startsWith('ff') || normalized.startsWith('::ffff:') || normalized.startsWith('2001:db8:');
  }
  return ['localhost', 'local', 'internal', 'test', 'invalid', 'lan', 'home.arpa'].some(suffix => host === suffix || host.endsWith(`.${suffix}`));
}

function isAllowedSource(raw) {
  const url = normalizeUrl(raw);
  return Boolean(url && !isPrivateAddress(new URL(url).hostname.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '')));
}

async function assertPublicUrl(raw, cache = new Map(), resolveHost = host => lookup(host, { all: true, verbatim: true })) {
  const url = normalizeUrl(raw);
  if (!url || !isAllowedSource(url)) throw new Error('URL must be a public HTTP(S) address; local and private destinations are not allowed.');
  const hostname = new URL(url).hostname.toLowerCase().replace(/\.$/, '');
  if (isIP(hostname)) return url;
  if (!cache.has(hostname)) {
    cache.set(hostname, Promise.resolve(resolveHost(hostname)).then(addresses => {
      if (!addresses.length || addresses.some(({ address }) => isPrivateAddress(address))) {
        throw new Error('Hostname resolves to a private or non-public address and was blocked.');
      }
      return addresses;
    }));
  }
  await cache.get(hostname);
  return url;
}

function isBlockedDomain(raw, blocked) {
  let host;
  try { host = new URL(raw).hostname.toLowerCase().replace(/^www\./, '').replace(/\.$/, ''); } catch { return true; }
  return blocked.some(value => {
    const domain = String(value).trim().toLowerCase().replace(/^www\./, '').replace(/\.$/, '');
    return domain && (host === domain || host.endsWith(`.${domain}`));
  });
}

function challengeKind(title, body) {
  const text = `${title}\n${body.slice(0, 12000)}`.toLowerCase();
  if (/captcha|recaptcha|hcaptcha|turnstile|verify you are human|not a robot|unusual traffic|\/sorry\//i.test(text)) return 'captcha_or_anti_bot';
  if (/cloudflare|checking your browser|just a moment\.\.\./i.test(text)) return 'cloudflare_challenge';
  if (/sign in to continue|log in to continue|please log in|login required|authentication required/i.test(text)) return 'login_required';
  return '';
}

function unwrapSearchUrl(raw, engine) {
  try {
    const url = new URL(raw);
    if (engine === 'google' && url.pathname === '/url') return url.searchParams.get('q') ?? url.searchParams.get('url') ?? raw;
    if (engine === 'duckduckgo' && url.pathname === '/l/') return url.searchParams.get('uddg') ?? raw;
  } catch {}
  return raw;
}

function searchPageUrl(query, pageNumber, config, engine) {
  const offset = (pageNumber - 1) * config.resultsPerPage;
  return engine === 'google'
    ? `https://www.google.com/search?q=${encodeURIComponent(query)}&start=${offset}&num=${config.resultsPerPage}&filter=0`
    : `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}&s=${offset}`;
}

function outputDirectoryPath(value) {
  return isAbsolute(value) ? resolve(value) : resolve(ROOT, value);
}

function safeQueryName(query) {
  const name = String(query).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^[._-]+|[._-]+$/g, '').slice(0, 100) || 'query';
  return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name) ? `q_${name}` : name;
}

function safeSourceName(value) {
  return String(value).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^[._-]+|[._-]+$/g, '').slice(0, 72) || 'source';
}

async function readConfig() {
  try { return JSON.parse(await readFile(join(ROOT, 'config.json'), 'utf8')); } catch { return {}; }
}

async function processPorts() {
  if (process.platform !== 'win32') return [];
  const script = "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(chrome|chromium|msedge|thorium)(\.exe)?$' -and $_.CommandLine }; foreach($x in $p){ foreach($m in [regex]::Matches($x.CommandLine,'--remote-debugging-port=(\\d+)')){ $m.Groups[1].Value } }";
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 2500, windowsHide: true, maxBuffer: 8192 });
    return stdout.split(/\s+/).map(Number).filter(port => Number.isInteger(port) && port > 0 && port <= MAX_PORT);
  } catch { return []; }
}

async function findDevToolsActivePorts() {
  if (process.platform !== 'win32') return [];
  const script = "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(chrome|chromium|msedge|thorium)(\.exe)?$' -and $_.CommandLine }; foreach($x in $p){ $m=[regex]::Match($x.CommandLine,'--user-data-dir=([^\\\"]+|\"[^\"]+\")'); if($m.Success){ $d=$m.Groups[1].Value.Trim('\"'); $f=Join-Path $d 'DevToolsActivePort'; if(Test-Path -LiteralPath $f){ $v=Get-Content -LiteralPath $f -TotalCount 1 -ErrorAction SilentlyContinue; if($v -match '^\\d+$'){ $v } } } }";
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 3000, windowsHide: true, maxBuffer: 8192 });
    return stdout.split(/\s+/).map(Number).filter(port => Number.isInteger(port) && port > 0 && port <= MAX_PORT);
  } catch { return []; }
}

async function endpointResponds(endpoint) {
  const base = normalizeEndpoint(endpoint);
  try {
    const response = await fetch(`${base.origin}/json/version`, { signal: AbortSignal.timeout(1200) });
    if (!response.ok) return false;
    const info = await response.json();
    return typeof info.webSocketDebuggerUrl === 'string' && new URL(info.webSocketDebuggerUrl).hostname.replace(/^\[|\]$/g, '') === base.hostname.replace(/^\[|\]$/g, '');
  } catch { return false; }
}

async function discoverEndpoint(config) {
  const candidates = [];
  if (config.cdpEndpoint) {
    const base = normalizeEndpoint(config.cdpEndpoint);
    candidates.push(endpointHttpBase(base.origin));
  }
  const ports = [...new Set([
    ...(Array.isArray(config.candidatePorts) ? config.candidatePorts : DEFAULT_PORTS),
    ...await processPorts(),
    ...await findDevToolsActivePorts(),
  ])].filter(port => Number.isInteger(port) && port > 0 && port <= MAX_PORT);
  for (const port of ports) {
    for (const host of ['127.0.0.1', 'localhost', '::1']) candidates.push(endpointAt(host, port));
  }
  for (const endpoint of [...new Set(candidates)]) if (await endpointResponds(endpoint)) return endpoint;
  throw new Error(`No existing localhost CDP browser responded. Checked the configured endpoint and ${ports.length} candidate port(s). Start an authorized Chromium-family browser with remote debugging enabled and retry. The plugin never launches a browser.`);
}

async function connectContext(config) {
  const endpoint = await discoverEndpoint(config);
  if (!activeBrowser?.isConnected() || activeEndpoint !== endpoint) {
    activeBrowser = await chromium.connectOverCDP(endpoint, { timeout: config.pageLoadTimeoutMs });
    activeEndpoint = endpoint;
  }
  const context = activeBrowser.contexts()[0];
  if (!context) throw new Error('CDP connected, but no existing browser context is available.');
  return { endpoint, context };
}

async function openWorkPage(context, config, tabId, title) {
  let page;
  try {
    page = await context.newPage();
    await page.evaluate(searchTitle => { document.title = searchTitle; }, title);
    if (config.mediaBlocking !== false) {
      await page.route('**/*', route => MEDIA_TYPES.has(route.request().resourceType()) ? route.abort() : route.continue());
    }
    return page;
  } catch (error) {
    error.tabId = tabId;
    error.pageStatus = 'failed';
    throw error;
  }
}

async function listSearchTabs(context) {
  const tabs = [];
  for (const page of context.pages()) {
    try {
      const title = await page.title();
      const isSearch = title.startsWith(SEARCH_TAB_PREFIX);
      const isSource = title.startsWith(SOURCE_TAB_PREFIX);
      if (!isSearch && !isSource) continue;
      const prefix = isSearch ? SEARCH_TAB_PREFIX : SOURCE_TAB_PREFIX;
      const match = isSearch
        ? title.match(/^MorpheusX SERP \| (?:(?<id>[\w-]+) \| )?p(?<page>\d+) \| (?<query>.*)$/)
        : title.match(/^MorpheusX Source \| (?:(?<id>[\w-]+) \| )?(?<label>.*)$/);
      const id = match?.groups.id || randomUUID();
      const label = isSearch ? `p${match?.groups.page || 0} | ${match?.groups.query || ''}` : match?.groups.label || 'Fetched page';
      if (!match?.groups.id) await page.evaluate(value => { document.title = value; }, `${prefix} ${id} | ${label}`).catch(() => {});
      const url = page.url();
      let searchEngine = isSource ? 'webpage' : 'unknown';
      try {
        const host = new URL(url).hostname;
        if (host === 'www.google.com') searchEngine = 'google';
        else if (host.endsWith('duckduckgo.com')) searchEngine = 'duckduckgo';
      } catch {}
      const displayTitle = `${prefix} ${id} | ${label}`;
      tabs.push({ id, kind: isSearch ? 'serp' : 'source', title: displayTitle, url, searchEngine, page: Number(match?.groups.page || 0), query: match?.groups.query || '' });
    } catch {}
  }
  return tabs;
}

async function closeSearchTabs(context, tabIds) {
  await listSearchTabs(context);
  const selected = new Set(tabIds);
  const closedTabIds = [];
  const notFoundTabIds = [];
  const failedTabIds = [];
  const closeErrors = [];
  for (const id of selected) {
    let selectedPage;
    for (const page of context.pages()) {
      try {
        const match = (await page.title()).match(/^MorpheusX (?:SERP|Source) \| ([\w-]+) \|/);
        if (match?.[1] === id) { selectedPage = page; break; }
      } catch {}
    }
    if (!selectedPage) { notFoundTabIds.push(id); continue; }
    try {
      await selectedPage.close();
      closedTabIds.push(id);
    } catch (error) {
      failedTabIds.push(id);
      closeErrors.push(`Could not close tab ${id}: ${error?.message || String(error)}`);
    }
  }
  return { closedTabIds, notFoundTabIds, failedTabIds, closeErrors };
}

async function pageChallenge(page) {
  try { return challengeKind(await page.title(), await page.locator('body').innerText({ timeout: 2000 })); } catch { return ''; }
}

async function searchPage(context, query, pageNumber, config, engine) {
  const tabId = randomUUID();
  const title = `${SEARCH_TAB_PREFIX} ${tabId} | p${pageNumber} | ${query}`;
  let page;
  let httpStatus;
  try {
    page = await openWorkPage(context, config, tabId, title);
    const url = searchPageUrl(query, pageNumber, config, engine);
    const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: config.pageLoadTimeoutMs });
    httpStatus = response?.status();
    if (response && response.status() >= 400) throw new Error(`Search page returned HTTP ${response.status()}.`);
    await page.waitForTimeout(config.searchSettleMs);
    const challenge = await pageChallenge(page);
    if (challenge) {
      const error = new Error(`Search engine challenge detected (${challenge}). The SERP tab is being kept open; solve it in the visible browser and rerun the query.`);
      error.pageStatus = 'challenge';
      error.tabId = tabId;
      error.httpStatus = httpStatus;
      throw error;
    }
    const candidates = await page.evaluate(searchEngine => {
      const cards = searchEngine === 'google'
        ? [...document.querySelectorAll('div.MjjYud')].length ? [...document.querySelectorAll('div.MjjYud')] : [...document.querySelectorAll('div.g')]
        : [...document.querySelectorAll('.result')];
      return cards.map(card => {
        const anchor = searchEngine === 'google'
          ? [...card.querySelectorAll('a[href]')].find(link => link.querySelector('h3'))
          : card.querySelector('a.result__a[href]');
        if (!anchor) return null;
        const title = card.querySelector('h3')?.innerText || anchor.innerText || anchor.textContent || '';
        const snippet = searchEngine === 'google'
          ? card.querySelector('.VwiC3b, .IsZvec, .ITZIwc, [data-sncf]')?.innerText || ''
          : card.querySelector('.result__snippet')?.innerText || '';
        return { href: anchor.href, title, snippet };
      }).filter(Boolean);
    }, engine);
    return { results: normalizeSearchResults(candidates, engine, pageNumber, config), tabId, httpStatus };
  } catch (error) {
    if (!error.tabId) error.tabId = tabId;
    if (!error.httpStatus) error.httpStatus = httpStatus;
    if (!error.pageStatus) error.pageStatus = 'failed';
    throw error;
  } finally {
    if (page) await page.evaluate(searchTitle => { document.title = searchTitle; }, title).catch(() => {});
  }
}

function normalizeSearchResults(candidates, engine, pageNumber, config) {
  const found = new Map();
  for (const candidate of candidates) {
    const url = normalizeUrl(unwrapSearchUrl(candidate.href, engine));
    const title = String(candidate.title || '').replace(/\s+/g, ' ').trim();
    if (!url || !title || !isAllowedSource(url) || isBlockedDomain(url, config.blockedDomains)) continue;
    const host = new URL(url).hostname.toLowerCase();
    if (engine === 'google' && /(^|\.)google\./i.test(host)) continue;
    if (engine === 'duckduckgo' && /(^|\.)duckduckgo\.com$/i.test(host)) continue;
    if (!found.has(url)) found.set(url, {
      url,
      title,
      domain: host,
      snippet: limitSourceContent(String(candidate.snippet || '').replace(/\s+/g, ' ').trim(), config.maxSourceCharacters),
      searchPage: pageNumber,
    });
  }
  return [...found.values()].slice(0, config.resultsPerPage);
}

function limitSourceContent(text, maxCharacters) {
  return String(text).slice(0, maxCharacters);
}

function renderResult(query, endpoint, results, outDir, manifestFile, pagesSearched, pagesVisited, skippedPages, pageAudit, lastPageSearched, searchErrors, config) {
  return {
    query,
    cdpEndpoint: endpoint,
    searchEngine: config.searchEngine,
    startPage: config.startPage,
    pagesRequested: config.pages,
    pagesSearched,
    pagesVisited,
    skippedPages,
    pageAudit,
    resultsPerPage: config.resultsPerPage,
    lastPageSearched,
    resultCount: results.length,
    outputDirectory: outDir,
    manifestFile,
    results,
    searchErrors,
  };
}

async function writeOutputs(results, config, metadata) {
  const baseDirectory = outputDirectoryPath(config.outputDirectory);
  const queryDirectory = join(baseDirectory, safeQueryName(metadata.query));
  await mkdir(queryDirectory, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const outDir = await mkdtemp(join(queryDirectory, `run-${stamp}-`));
  const sourceDirectory = join(outDir, 'sources');
  await mkdir(sourceDirectory);
  const extension = config.sourceFormat;
  const savedResults = await Promise.all(results.map(async (result, index) => {
    const ordinal = String(index + 1).padStart(3, '0');
    const stem = safeSourceName(`${result.domain}-${result.title}`);
    const filename = `page-${String(result.searchPage).padStart(3, '0')}-result-${ordinal}-${stem}.${extension}`;
    const contentFile = join(sourceDirectory, filename);
    const text = extension === 'md'
      ? `# ${result.title}\n\n- Search results page: ${result.searchPage}\n- URL: ${result.url}\n- Domain: ${result.domain}\n\n## Search result excerpt\n\n${result.snippet || '(No excerpt was provided by the search engine.)'}\n`
      : `Title: ${result.title}\nSearch results page: ${result.searchPage}\nURL: ${result.url}\nDomain: ${result.domain}\n\nSearch result excerpt:\n${result.snippet || '(No excerpt was provided by the search engine.)'}\n`;
    await writeFile(contentFile, text, 'utf8');
    return { ...result, contentFile };
  }));
  const manifestFile = join(outDir, 'manifest.json');
  const manifest = {
    query: metadata.query,
    generatedAt: new Date().toISOString(),
    searchEngine: config.searchEngine,
    startPage: config.startPage,
    pagesRequested: config.pages,
    pagesSearched: metadata.pagesSearched,
    pagesVisited: metadata.pagesVisited,
    skippedPages: metadata.skippedPages,
    pageAudit: metadata.pageAudit,
    lastPageSearched: metadata.lastPageSearched,
    maxResults: config.maxResults,
    resultsPerPage: config.resultsPerPage,
    resultCount: savedResults.length,
    maxSourceCharacters: config.maxSourceCharacters,
    sourceFormat: config.sourceFormat,
    retryCount: config.retryCount,
    results: savedResults,
    searchErrors: metadata.searchErrors,
  };
  await writeFile(manifestFile, JSON.stringify(manifest, null, 2), 'utf8');
  return { outDir, manifestFile, results: savedResults };
}

function normalizeQuery(query) {
  return String(query).trim().toLowerCase().replace(/\s+/g, ' ');
}

async function loadSearchHistory(config) {
  const baseDirectory = outputDirectoryPath(config.outputDirectory);
  const history = { searchedPages: new Map(), seenUrls: new Set() };
  let queryDirectories = [];
  try { queryDirectories = await readdir(baseDirectory, { withFileTypes: true }); } catch { return history; }
  for (const queryEntry of queryDirectories) {
    if (!queryEntry.isDirectory()) continue;
    const queryDirectory = join(baseDirectory, queryEntry.name);
    let runs = [];
    try { runs = await readdir(queryDirectory, { withFileTypes: true }); } catch { continue; }
    for (const runEntry of runs) {
      if (!runEntry.isDirectory()) continue;
      let manifest;
      try { manifest = JSON.parse(await readFile(join(queryDirectory, runEntry.name, 'manifest.json'), 'utf8')); } catch { continue; }
      const key = normalizeQuery(manifest.query || queryEntry.name.replace(/_/g, ' '));
      if (!history.searchedPages.has(key)) history.searchedPages.set(key, new Set());
      const pages = history.searchedPages.get(key);
      const visited = Array.isArray(manifest.pagesVisited) ? manifest.pagesVisited : [];
      for (const page of visited) if (Number.isInteger(page) && page > 0) pages.add(page);
      if (!Array.isArray(manifest.pagesVisited) && Number.isInteger(manifest.startPage) && Number.isInteger(manifest.pagesSearched)) {
        for (let page = manifest.startPage; page < manifest.startPage + manifest.pagesSearched; page++) pages.add(page);
      }
      for (const result of [...(Array.isArray(manifest.results) ? manifest.results : []), ...(Array.isArray(manifest.sources) ? manifest.sources : [])]) {
        const url = normalizeUrl(result?.url);
        if (url) history.seenUrls.add(url);
      }
    }
  }
  return history;
}

function mergeConfig(file, args) {
  const merged = { ...DEFAULT_CONFIG, ...file, ...Object.fromEntries(Object.entries(args).filter(([, value]) => value !== undefined)) };
  delete merged.maxReturnedCharacters;
  delete merged.outputFormat;
  delete merged.maxConcurrency;
  delete merged.sourceSettleMs;
  merged.resultsPerPage = boundedInteger(merged.resultsPerPage, 10, 1, 100);
  const maxResultsInput = args.maxResults ?? file.maxResults;
  const pagesInput = args.pages ?? (Number.isInteger(maxResultsInput) ? Math.ceil(maxResultsInput / merged.resultsPerPage) : merged.pages);
  merged.pages = boundedInteger(pagesInput, 1, 1, 100);
  merged.startPage = boundedInteger(merged.startPage, 1, 1, 10000);
  const pageCapacity = merged.pages * merged.resultsPerPage;
  merged.maxResults = boundedInteger(maxResultsInput, pageCapacity, 1, 1000);
  merged.maxSourceCharacters = boundedInteger(merged.maxSourceCharacters, 4000, 100, 1000000);
  merged.maxPageCharacters = boundedInteger(merged.maxPageCharacters, 20000, 1000, 500000);
  merged.maxLinksPerPage = boundedInteger(merged.maxLinksPerPage, 100, 0, 1000);
  merged.fetchConcurrency = boundedInteger(merged.fetchConcurrency, 2, 1, 5);
  merged.retryCount = boundedInteger(merged.retryCount, 1, 0, 3);
  merged.pageLoadTimeoutMs = boundedInteger(merged.pageLoadTimeoutMs, 35000, 1000, 120000);
  merged.searchSettleMs = boundedInteger(merged.searchSettleMs, 450, 0, 10000);
  merged.sourceFormat = merged.sourceFormat === 'txt' ? 'txt' : 'md';
  merged.searchEngine = String(merged.searchEngine || 'google').toLowerCase();
  if (!['google', 'duckduckgo', 'ddg'].includes(merged.searchEngine)) throw new Error('searchEngine must be google or duckduckgo.');
  if (!Array.isArray(merged.blockedDomains) || merged.blockedDomains.some(x => typeof x !== 'string')) throw new Error('blockedDomains must be an array of domain strings.');
  if (!merged.outputDirectory || typeof merged.outputDirectory !== 'string') throw new Error('outputDirectory must be a non-empty path.');
  return merged;
}

async function runResearch(args) {
  if (!args || typeof args.query !== 'string' || !args.query.trim()) throw new Error('query must be a non-empty string.');
  const fileConfig = await readConfig();
  const config = mergeConfig(fileConfig, args);
  const { endpoint, context } = await connectContext(config);
  const engine = config.searchEngine === 'ddg' ? 'duckduckgo' : config.searchEngine;
  const query = args.query.trim();
  const history = await loadSearchHistory(config);
  const queryPages = history.searchedPages.get(normalizeQuery(query)) || new Set();
  const collected = new Map();
  const searchErrors = [];
  const pagesVisited = [];
  const skippedPages = [];
  const pageAudit = [];
  const seenUrls = config.deduplicateResults === false ? new Set() : new Set(history.seenUrls);
  let pagesSearched = 0;
  let lastPageSearched = Math.max(0, ...queryPages);
  let challengeDetected = false;
  for (let pageNo = config.startPage; pageNo < config.startPage + config.pages && collected.size < config.maxResults; pageNo++) {
    if (!config.allowRepeatPages && queryPages.has(pageNo)) {
      skippedPages.push(pageNo);
      pageAudit.push({ page: pageNo, status: 'skipped', attempts: 0, extractedResults: 0, returnedResults: 0, tabIds: [] });
      searchErrors.push(`Search results page ${pageNo} was already searched for this query and was skipped. Set allowRepeatPages=true to search it again.`);
      continue;
    }
    pagesSearched++;
    const audit = { page: pageNo, status: 'failed', attempts: 0, extractedResults: 0, returnedResults: 0, tabIds: [] };
    let pageResults;
    let lastError;
    for (let attempt = 0; attempt <= config.retryCount; attempt++) {
      audit.attempts++;
      try {
        pageResults = await searchPage(context, query, pageNo, config, engine);
        audit.tabIds.push(pageResults.tabId);
        audit.status = 'read';
        if (Number.isInteger(pageResults.httpStatus)) audit.httpStatus = pageResults.httpStatus;
        audit.extractedResults = pageResults.results.length;
        pagesVisited.push(pageNo);
        lastPageSearched = Math.max(lastPageSearched, pageNo);
        break;
      } catch (error) {
        lastError = error;
        if (error?.tabId) audit.tabIds.push(error.tabId);
        if (Number.isInteger(error?.httpStatus)) audit.httpStatus = error.httpStatus;
        audit.status = error?.pageStatus || 'failed';
        if (/challenge detected/i.test(String(error?.message || error))) {
          challengeDetected = true;
          break;
        }
        if (attempt < config.retryCount) await new Promise(resolve => setTimeout(resolve, 350 * (attempt + 1)));
      }
    }
    if (lastError && !pageResults) audit.error = `${lastError?.name || 'Error'}: ${lastError?.message || String(lastError)}`;
    pageAudit.push(audit);
    if (lastError && !pageResults) searchErrors.push(`Search results page ${pageNo}: ${lastError?.name || 'Error'}: ${lastError?.message || String(lastError)}`);
    const returnedBeforePage = collected.size;
    for (const item of pageResults?.results || []) {
      if (!seenUrls.has(item.url) && !collected.has(item.url) && collected.size < config.maxResults) collected.set(item.url, item);
    }
    audit.returnedResults = collected.size - returnedBeforePage;
    for (const item of pageResults?.results || []) seenUrls.add(item.url);
    if (challengeDetected) break;
  }
  const results = [...collected.values()];
  const output = await writeOutputs(results, config, { query, pagesSearched, pagesVisited, skippedPages, pageAudit, lastPageSearched, searchErrors });
  return renderResult(query, endpoint, output.results, output.outDir, output.manifestFile, pagesSearched, pagesVisited, skippedPages, pageAudit, lastPageSearched, searchErrors, config);
}

async function runWithConcurrency(items, concurrency, mapper) {
  const results = new Array(items.length);
  let nextIndex = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (nextIndex < items.length) {
      const index = nextIndex++;
      results[index] = await mapper(items[index]);
    }
  }));
  return results;
}

async function fetchOnePage(context, rawUrl, inputIndex, config, dnsCache) {
  let url;
  try { url = await assertPublicUrl(rawUrl, dnsCache); }
  catch (error) {
    return { inputIndex, url: String(rawUrl), finalUrl: '', title: '', domain: '', status: 'rejected', tabId: '', extractedCharacters: 0, returnedCharacters: 0, truncated: false, content: '', contentFile: '', links: [], error: `${error?.message || String(error)}` };
  }
  const tabId = randomUUID();
  const originalHost = new URL(url).hostname;
  const result = { inputIndex, url, finalUrl: url, title: '', domain: originalHost, status: 'failed', tabId: '', extractedCharacters: 0, returnedCharacters: 0, truncated: false, content: '', contentFile: '', links: [] };
  const title = `${SOURCE_TAB_PREFIX} ${tabId} | ${originalHost}`;
  let page;
  try {
    page = await context.newPage();
    result.tabId = tabId;
    await page.evaluate(searchTitle => { document.title = searchTitle; }, title);
    await page.route('**/*', async route => {
      const request = route.request();
      if (config.mediaBlocking !== false && MEDIA_TYPES.has(request.resourceType())) return route.abort().catch(() => {});
      try {
        await assertPublicUrl(request.url(), dnsCache);
        await route.continue();
      } catch {
        await route.abort().catch(() => {});
      }
    });
    const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: config.pageLoadTimeoutMs });
    if (Number.isInteger(response?.status())) result.httpStatus = response.status();
    result.finalUrl = page.url();
    if (response && response.status() >= 400) throw new Error(`The page returned HTTP ${response.status()}.`);
    await page.waitForTimeout(config.searchSettleMs);
    const challenge = await pageChallenge(page);
    if (challenge) {
      result.status = 'challenge';
      result.error = `A page challenge was detected (${challenge}); the tab remains open.`;
      return result;
    }
    const extracted = await page.evaluate(maxLinks => {
      const candidates = [...document.querySelectorAll('article, main, [role="main"]')];
      const root = candidates.sort((a, b) => (b.innerText || '').length - (a.innerText || '').length)[0] || document.body;
      const clean = root.cloneNode(true);
      clean.querySelectorAll('script, style, noscript, svg, nav, footer, header, aside, form, [aria-hidden="true"]').forEach(node => node.remove());
      const text = (clean.innerText || clean.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
      const unique = new Map();
      if (maxLinks > 0) for (const anchor of document.querySelectorAll('a[href]')) {
        const label = (anchor.innerText || anchor.textContent || '').replace(/\s+/g, ' ').trim();
        let href;
        try { href = new URL(anchor.href).href; } catch { continue; }
        if (label && /^https?:$/.test(new URL(href).protocol) && !unique.has(href)) unique.set(href, { text: label, url: href });
        if (unique.size >= maxLinks) break;
      }
      return { title: document.title || '', text, links: [...unique.values()] };
    }, config.maxLinksPerPage);
    result.title = extracted.title;
    result.finalUrl = page.url();
    result.domain = new URL(result.finalUrl).hostname;
    result.extractedCharacters = extracted.text.length;
    result.content = limitSourceContent(extracted.text, config.maxPageCharacters);
    result.returnedCharacters = result.content.length;
    result.truncated = result.returnedCharacters < result.extractedCharacters;
    result.links = extracted.links.filter(link => isAllowedSource(link.url)).slice(0, config.maxLinksPerPage);
    result.status = result.content ? 'read' : 'empty';
    if (result.status === 'empty') result.error = 'The page loaded, but no readable text was extracted.';
    return result;
  } catch (error) {
    result.finalUrl = page?.url() || url;
    if (page) {
      try { result.title = await page.title(); } catch {}
      const challenge = await pageChallenge(page);
      if (challenge) result.status = 'challenge';
    }
    result.error = `${error?.name || 'Error'}: ${error?.message || String(error)}`;
    return result;
  } finally {
    if (page) await page.evaluate(searchTitle => { document.title = searchTitle; }, `${SOURCE_TAB_PREFIX} ${tabId} | ${result.title || originalHost}`).catch(() => {});
  }
}

async function writeFetchedPages(pages, config, urlsRequested) {
  const outputRoot = outputDirectoryPath(config.outputDirectory);
  const fetchRoot = join(outputRoot, 'fetched-pages');
  await mkdir(fetchRoot, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const runDirectory = await mkdtemp(join(fetchRoot, `run-${stamp}-`));
  const sourcesDirectory = join(runDirectory, 'sources');
  await mkdir(sourcesDirectory);
  const savedPages = await Promise.all(pages.map(async (page, index) => {
    if (page.status !== 'read') return page;
    const filename = `source-${String(index + 1).padStart(3, '0')}-${safeSourceName(`${page.domain}-${page.title || page.url}`)}.${config.sourceFormat}`;
    const contentFile = join(sourcesDirectory, filename);
    const content = config.sourceFormat === 'md'
      ? `# ${page.title || page.domain}\n\n- URL: ${page.url}\n- Final URL: ${page.finalUrl}\n- HTTP status: ${page.httpStatus ?? 'unavailable'}\n- Page status: ${page.status}\n- Text characters: ${page.returnedCharacters}${page.truncated ? ` of ${page.extractedCharacters} (truncated)` : ''}\n\n## Page text\n\n${page.content}\n\n## Links found on this page\n\n${page.links.map(link => `- [${link.text}](${link.url})`).join('\n') || '(No public HTTP(S) links were extracted.)'}\n`
      : `Title: ${page.title || page.domain}\nURL: ${page.url}\nFinal URL: ${page.finalUrl}\nHTTP status: ${page.httpStatus ?? 'unavailable'}\nPage status: ${page.status}\nText characters: ${page.returnedCharacters}${page.truncated ? ` of ${page.extractedCharacters} (truncated)` : ''}\n\nPage text:\n${page.content}\n\nLinks found on this page:\n${page.links.map(link => `${link.text}: ${link.url}`).join('\n') || '(No public HTTP(S) links were extracted.)'}\n`;
    await writeFile(contentFile, content, 'utf8');
    return { ...page, contentFile };
  }));
  const pagesRead = savedPages.filter(page => page.status === 'read').length;
  const pagesAttempted = savedPages.filter(page => ['read', 'empty', 'failed', 'challenge'].includes(page.status)).length;
  const manifestFile = join(runDirectory, 'manifest.json');
  const manifest = {
    urlsRequested,
    pagesAttempted,
    pagesRead,
    generatedAt: new Date().toISOString(),
    maxPageCharacters: config.maxPageCharacters,
    maxLinksPerPage: config.maxLinksPerPage,
    fetchConcurrency: config.fetchConcurrency,
    pages: savedPages.map(({ content, ...page }) => page),
  };
  await writeFile(manifestFile, JSON.stringify(manifest, null, 2), 'utf8');
  return { urlsRequested, pagesAttempted, pagesRead, pages: savedPages, manifestFile, outputDirectory: runDirectory, errors: [] };
}

async function fetchPages(args) {
  if (!Array.isArray(args?.urls) || args.urls.length === 0) throw new Error('urls must contain one or more page URLs.');
  if (args.urls.length > 20) throw new Error('Fetch at most 20 URLs per call; choose only the pages relevant to the research question.');
  if (args.urls.some(url => typeof url !== 'string')) throw new Error('Every urls entry must be a string.');
  const config = mergeConfig(await readConfig(), args);
  config.maxPageCharacters = boundedInteger(config.maxPageCharacters, 20000, 1000, 500000);
  config.maxLinksPerPage = boundedInteger(config.maxLinksPerPage, 100, 0, 1000);
  config.fetchConcurrency = boundedInteger(config.fetchConcurrency, 2, 1, 5);
  const { context } = await connectContext(config);
  const normalized = args.urls.map(url => normalizeUrl(url));
  const firstIndexes = new Map();
  const work = [];
  const pages = new Array(args.urls.length);
  for (let index = 0; index < args.urls.length; index++) {
    const url = normalized[index];
    if (url && isAllowedSource(url) && firstIndexes.has(url)) {
      pages[index] = { inputIndex: index + 1, url: String(args.urls[index]), finalUrl: '', title: '', domain: '', status: 'duplicate', tabId: '', extractedCharacters: 0, returnedCharacters: 0, truncated: false, content: '', contentFile: '', links: [], duplicateOfInputIndex: firstIndexes.get(url) };
      continue;
    }
    if (url && isAllowedSource(url)) firstIndexes.set(url, index + 1);
    work.push({ index, url: args.urls[index] });
  }
  const dnsCache = new Map();
  const fetched = await runWithConcurrency(work, config.fetchConcurrency, async item => fetchOnePage(context, item.url, item.index + 1, config, dnsCache));
  for (let index = 0; index < work.length; index++) pages[work[index].index] = fetched[index];
  try { return await writeFetchedPages(pages, config, args.urls.length); }
  catch (error) {
    return {
      urlsRequested: args.urls.length,
      pagesAttempted: pages.filter(page => ['read', 'empty', 'failed', 'challenge'].includes(page.status)).length,
      pagesRead: pages.filter(page => page.status === 'read').length,
      pages,
      manifestFile: '',
      outputDirectory: '',
      errors: [`Page fetching completed, but saving its output failed: ${error?.message || String(error)}`],
    };
  }
}

async function manageSearchTabs(args) {
  if (!['list', 'close'].includes(args?.action)) throw new Error('action must be list or close.');
  if (args.action === 'close' && (!Array.isArray(args.tabIds) || args.tabIds.length === 0 || args.tabIds.some(id => typeof id !== 'string'))) {
    throw new Error('Closing tabs requires one or more tabIds from a prior list action.');
  }
  const config = mergeConfig(await readConfig(), args);
  const { context } = await connectContext(config);
  if (args.action === 'list') return { action: 'list', tabs: await listSearchTabs(context), closedTabIds: [], notFoundTabIds: [], failedTabIds: [], searchErrors: [] };
  const closed = await closeSearchTabs(context, args.tabIds);
  return { action: 'close', tabs: await listSearchTabs(context), closedTabIds: closed.closedTabIds, notFoundTabIds: closed.notFoundTabIds, failedTabIds: closed.failedTabIds, searchErrors: closed.closeErrors };
}

export function apply(ctx) {
  ctx.tools.register({
    name: 'morpheusx_research',
    description: 'Read Google or DuckDuckGo search-result pages in an already-running localhost CDP browser. Each SERP remains open in a new tab. Search returns snippets only; use morpheusx_fetch_pages to deliberately fetch selected URLs. Returns per-page audit counts. Default is one page of ten results.',
    parameters: { type: 'object', properties: parameterFields, required: ['query'], additionalProperties: false },
    output: {
      schema: outputSchema,
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args) {
      try { return await runResearch(args); }
      catch (error) {
        return {
          query: String(args?.query ?? ''), cdpEndpoint: '', searchEngine: String(args?.searchEngine || 'google'),
          startPage: Number.isInteger(args?.startPage) ? args.startPage : 1,
          pagesRequested: Number.isInteger(args?.pages) ? args.pages : 1,
          pagesSearched: 0, pagesVisited: [], skippedPages: [], pageAudit: [], lastPageSearched: 0, resultsPerPage: Number.isInteger(args?.resultsPerPage) ? args.resultsPerPage : 10,
          maxResults: Number.isInteger(args?.maxResults) ? args.maxResults : (Number.isInteger(args?.pages) ? args.pages : 1) * (Number.isInteger(args?.resultsPerPage) ? args.resultsPerPage : 10), resultCount: 0,
          outputDirectory: '', manifestFile: '', results: [],
          searchErrors: [`${error?.name || 'Error'}: ${error?.message || String(error)}`],
        };
      }
    },
  });
  ctx.tools.register({
    name: 'morpheusx_search_tabs',
    description: 'List currently open MorpheusX SERP and fetched-source tabs, or close selected tab IDs returned by list. It never closes ordinary browser tabs.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['list', 'close'], description: 'List currently open MorpheusX SERP and fetched-source tabs or close selected tabs.' },
        tabIds: { type: 'array', items: { type: 'string' }, description: 'For close, the exact tab IDs returned by a previous list action.' },
      },
      required: ['action'],
      additionalProperties: false,
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          action: { type: 'string' },
          tabs: { type: 'array', items: { type: 'object', properties: {
            id: { type: 'string' }, kind: { type: 'string' }, title: { type: 'string' }, url: { type: 'string' }, searchEngine: { type: 'string' }, page: { type: 'integer' }, query: { type: 'string' },
          }, required: ['id', 'kind', 'title', 'url', 'searchEngine', 'page', 'query'] } },
          closedTabIds: { type: 'array', items: { type: 'string' } },
          notFoundTabIds: { type: 'array', items: { type: 'string' } },
          failedTabIds: { type: 'array', items: { type: 'string' } },
          searchErrors: { type: 'array', items: { type: 'string' } },
        },
        required: ['action', 'tabs', 'closedTabIds', 'notFoundTabIds', 'failedTabIds', 'searchErrors'],
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args) {
      try { return await manageSearchTabs(args); }
      catch (error) { return { action: String(args?.action || ''), tabs: [], closedTabIds: [], notFoundTabIds: [], failedTabIds: [], searchErrors: [`${error?.name || 'Error'}: ${error?.message || String(error)}`] }; }
    },
  });
  ctx.tools.register({
    name: 'morpheusx_fetch_pages',
    description: 'Fetch only explicitly selected public HTTP(S) URLs in the existing browser, one retained new tab per URL. Returns readable page text, extracted public links, actual statuses, and per-page character counts. Use for URLs selected from search results, links found on a fetched page, or a URL supplied by the user. Does not recursively crawl links.',
    parameters: { type: 'object', properties: fetchParameters, required: ['urls'], additionalProperties: false },
    output: {
      schema: fetchOutputSchema,
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args) {
      try { return await fetchPages(args); }
      catch (error) {
        return {
          urlsRequested: Array.isArray(args?.urls) ? args.urls.length : 0,
          pagesAttempted: 0,
          pagesRead: 0,
          pages: [],
          manifestFile: '',
          outputDirectory: '',
          errors: [`${error?.name || 'Error'}: ${error?.message || String(error)}`],
        };
      }
    },
  });
}

export const __test = { normalizeEndpoint, endpointHttpBase, normalizeUrl, isBlockedDomain, isAllowedSource, isPrivateAddress, assertPublicUrl, safeQueryName, safeSourceName, searchPageUrl, normalizeSearchResults, limitSourceContent, challengeKind, mergeConfig, writeOutputs, loadSearchHistory, listSearchTabs, closeSearchTabs, fetchOnePage, runWithConcurrency, writeFetchedPages, processPorts, findDevToolsActivePorts };
