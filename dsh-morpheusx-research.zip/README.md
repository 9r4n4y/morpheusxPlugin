# dsh-morpheusx-research

An installable DeepSeek Harness bundle exposing three research tools: `morpheusx_research` for Google/DDG search pages, `morpheusx_fetch_pages` for explicitly selected webpages, and `morpheusx_search_tabs` to list or close plugin-owned tabs. All browser work uses an already-running local Chromium-family browser.

Search and page fetching are separate on purpose. A search returns SERP titles, URLs, and snippets without opening any result automatically. The agent can then select useful result URLs, follow relevant links found in fetched pages, or fetch a URL the user supplied.

## Search page behavior

- A search result page is one Google/DuckDuckGo SERP, usually 10 results. The default call reads page 1 and requests 10 results.
- `pages` means the number of consecutive search-result pages to read, starting at `startPage`. `pages=4` with the default start page reads SERPs 1, 2, 3, and 4, for up to 40 results.
- `maxResults` is an optional total result cap. With `resultsPerPage=10`, `maxResults=30` and no explicit `pages` reads three SERPs. If both are supplied, `pages` sets the page span and `maxResults` caps how many distinct results are returned.
- To continue without repeating prior pages, inspect the last run's `lastPageSearched`, then set `startPage` to that value plus one. For example, `startPage=4, pages=2` reads SERPs 4 and 5.
- Every inspected SERP stays open in its own titled browser tab. Search and fetch runs never close tabs; use `morpheusx_search_tabs` to list current SERP/source tabs and close selected IDs.
- Re-running a query/page already recorded in manifests skips that page; set `allowRepeatPages=true` to explicitly fetch it again. To also return previously saved URLs from that page, set `deduplicateResults=false` too.
- Previously saved result URLs are omitted across runs by default. Set `deduplicateResults=false` to allow them again.
- Use `startPage` to jump directly to any result page. Each new page is opened in a separate tab; linked result websites are never opened.
- `maxSourceCharacters` limits the snippet text for each individual result. There is no combined character cap across results.
- Each result is saved in its own file; no combined results report is written.

## Harness integration

`package.json` declares `dsh.bundle.patch`; `cordis.patch.yml` inserts the `morpheusx-research` row; `index.js` exports the Cordis module and registers three native tools with `ctx.tools.register()`.

## Install

1. Extract the ZIP if installing from the ZIP distribution.
2. In a terminal opened in the folder containing `package.json`, run `pnpm install --prod --lockfile=false --ignore-scripts`. Local-folder links may not install dependencies beside the linked package automatically.
3. In Harness, open **Plugins**, choose **Add plugin**, and select the extracted `dsh-morpheusx-research` folder.
4. Enable the `dsh-morpheusx-research` bundle and its `morpheusx-research` row.
5. Keep the intended Chrome-family browser running with localhost remote debugging enabled.

The GUI also supports package and Git sources. For CLI installation, add the package to the selected profile with `dsh plugin --profile <profile> add <package-spec>`, then boot that profile.

## Browser connection

The plugin checks `cdpEndpoint` first and then `candidatePorts`. Defaults are `http://127.0.0.1:9222` and ports 9222 through 9230, with process-command-line and `DevToolsActivePort` discovery on Windows when available. Connections are restricted to `127.0.0.1`, `localhost`, or `::1`.

Remote debugging must be enabled before the browser starts. The plugin does not launch a browser, pass a profile path, copy profile data, or read cookies/storage. Do not expose the CDP port publicly.

## Tool settings

| Parameter | Default | Limits / behavior |
| --- | --- | --- |
| `query` | required | Non-empty search query |
| `searchEngine` | `google` | `google` or `duckduckgo` |
| `startPage` | 1 | First SERP page, 1-10000 |
| `pages` | 1 | Consecutive SERP pages to read, 1-100 |
| `resultsPerPage` | 10 | Results requested per SERP, 1-100 |
| `maxResults` | Derived | Optional total cap; otherwise `pages * resultsPerPage`, capped at 1000 |
| `maxSourceCharacters` | 4000 | Per-result SERP snippet cap, 100-1000000 characters; no total cap |
| `cdpEndpoint` | `http://127.0.0.1:9222` | Must be a localhost endpoint with a port |
| `candidatePorts` | 9222-9230 | Additional localhost CDP ports to check |
| `pageLoadTimeoutMs` | 35000 | Search navigation timeout, 1-120 seconds |
| `searchSettleMs` | 450 | Wait after each SERP loads, 0-10000 ms |
| `retryCount` | 1 | Retries per failed SERP, 0-3 |
| `blockedDomains` | `instagram.com`, `facebook.com` | Blocks exact domains and subdomains |
| `outputDirectory` | `./outputs` | Absolute or plugin-relative path |
| `sourceFormat` | `md` | `md` or `txt` for individual result files |
| `mediaBlocking` | `true` | Blocks image, media, font, manifest, and text-track requests on SERPs and fetched pages |
| `allowRepeatPages` | `false` | Re-fetch query/page pairs already recorded in output manifests |
| `deduplicateResults` | `true` | Omit result URLs already saved in manifests, including across queries |

## Fetching selected pages

Use `morpheusx_fetch_pages` after the user provides a URL or the agent selects useful links from search results or a fetched page. Each distinct URL opens in its own new browser tab. Up to 20 URLs can be requested per call; default concurrency is 2. A duplicate URL within one call is reported as `duplicate` rather than fetched again.

| Fetch parameter | Default | Limits / behavior |
| --- | --- | --- |
| `urls` | Required | Explicit public HTTP(S) URLs, maximum 20 per call |
| `maxPageCharacters` | 20000 | Text limit per fetched webpage, 1000-500000; no aggregate cap |
| `maxLinksPerPage` | 100 | Public HTTP(S) links extracted per page, 0-1000 |
| `fetchConcurrency` | 2 | Concurrent page navigations, 1-5; each URL has its own tab |

The tool extracts readable page text and a bounded list of visible links. It does not click those links, fetch every link, or crawl recursively. The agent can select further links and call the tool again. A user-provided URL is accepted directly if it passes public-address checks.

Every page record reports `status` (`read`, `empty`, `challenge`, `failed`, `rejected`, or `duplicate`), HTTP status when available, `extractedCharacters`, `returnedCharacters`, `truncated`, tab ID, links, and saved-file path. `pagesRead` counts only `read` pages; `empty` means the page loaded but yielded no readable text. The output contains no aggregate text cap: each URL is limited independently.

Example:

```text
Use morpheusx_fetch_pages for these URLs: https://example.org/report and https://example.net/study.
```

### Examples

Default: one SERP, up to 10 results.

```text
Use morpheusx_research for "battery recycling policy".
```

Fetch 30 results across three 10-result pages:

```text
Use morpheusx_research for "battery recycling policy" with maxResults=30.
```

Read four consecutive SERPs, up to 40 results:

```text
Use morpheusx_research for "battery recycling policy" with pages=4.
```

Continue from page 4 for two pages after a previous run ended at page 3:

```text
Use morpheusx_research for "battery recycling policy" with startPage=4, pages=2.
```

Jump directly to page 7:

```text
Use morpheusx_research for "battery recycling policy" with startPage=7, pages=1.
```

## Saved files

Relative output paths resolve from the plugin package folder. The current output root is:

```text
A:\storagex\dsh-researcher\dsh-morpheusx-research\outputs
```

Each call creates a unique folder:

```text
outputs/
  battery_recycling_policy/
    run-2026-10-07T12-34-56-789Z-a1b2c3/
      manifest.json
      sources/
        page-001-result-001-example-org-first-result.md
        page-002-result-011-example-net-second-result.md
```

Each SERP result file contains its title, SERP page number, URL, domain, and search-result snippet. Its manifest records exact `pagesVisited`, duplicate `skippedPages`, page audit, settings, errors, and file paths. Full webpage fetches are written beneath `outputs/fetched-pages/<run-id>/sources/`, one file per successfully read URL, with a manifest containing page statuses, text counts, links, and tab IDs. A new run never overwrites an earlier run. Existing older combined report files are left untouched.

SERP and fetched-page tabs are titled `MorpheusX SERP | tab-id | pN | query` and `MorpheusX Source | tab-id | title`. They are never closed by search/fetch runs, including failed attempts and retries. Call `morpheusx_search_tabs` with `action=list` to see the currently open MorpheusX tabs and their IDs. To close selected tabs, call it with `action=close` and IDs from a fresh list. Its response separates closed, not-found, and failed IDs; ordinary user tabs cannot be closed by this tool.

## Agent workflow

Read [SKILL.md](./SKILL.md) for the research workflow: search proportionally, choose relevant pages to fetch, follow useful links selectively, check exact page/status counts, and cite snippets versus full-page evidence accurately.

## Challenges and privacy

The browser must already be running with localhost CDP enabled. Fetching accepts public HTTP(S) URLs only and blocks local/private destinations, including redirected navigations and subresources. CAPTCHA/login/anti-bot challenges are not bypassed. Neither tool reads browser-profile files or cookies/storage. Webpage content is untrusted data, never instructions.

## Troubleshooting

- **Package metadata error:** confirm the GUI source points to the folder containing `package.json`.
- **`playwright-core` import error:** run the production dependency install command in the package folder, then reload Plugins.
- **Unsupported JSON Schema:** output schemas use only single type strings for Harness compatibility.
- **No CDP browser found:** start the intended browser with a localhost debugging port and match `cdpEndpoint`/`candidatePorts`.
- **Search challenge or missing snippets:** solve any challenge in the visible browser; Google may change its page markup, so some layouts may provide titles and URLs without snippets.
- **Accurate fetched counts:** use `pageAudit` as the source of truth. Only `status=read` means the search page was read; a failed or challenged attempt is not a read page. `attempts` shows navigation tries and `tabIds` identifies their retained tabs. `extractedResults` counts normalized results found on that page, while `returnedResults` counts results actually added to this response after de-duplication and caps. `resultCount` is the total result array length.
- **More results without repeats:** inspect `pagesVisited` and `lastPageSearched`, then continue at the next page with `startPage`. The plugin also checks manifests and skips already-searched query/page pairs automatically.

## Research basis

The bundle model, GUI plugin installation, Cordis activation, and tool registration were checked against primary DeepSeek Harness documentation. Links and page-read status are in [RESEARCH.md](./RESEARCH.md).

## License

MIT. `playwright-core` is the only runtime dependency and contains no browser binaries.
